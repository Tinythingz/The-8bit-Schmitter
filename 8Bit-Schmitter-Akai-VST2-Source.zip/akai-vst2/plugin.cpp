#include "engine.inc"
#include "factory-presets.inc"

struct Parameter {
    const char* name;
    std::atomic<int>* target;
    int low, high, bit=-1;
    int read() const { return bit < 0 ? target->load() : (target->load() >> bit) & 1; }
    void write(int value) const {
        if(bit < 0) target->store(value);
        else if(value) target->fetch_or(1 << bit);
        else target->fetch_and(~(1 << bit));
    }
};

constexpr int runIndex=69, fxStart=70, randomTarget=78, randomAction=79;
constexpr int savedParameterCount=80, firstStepLight=80, valueDial=82, firstEditKey=83;
constexpr int editTargets[]{2,3,4,5,6,8,9,10,11,12,14,15,16,18,19,70,71,72,73,74,75,76,77,
    23,25,27,29,31,33,37,39,41,43,45,47,21,35,0};
constexpr int firstModeKey=firstEditKey+std::size(editTargets);
constexpr int functionGroup=firstModeKey+2, firstFunctionKey=functionGroup+1;
constexpr int functionTargets[]{2,8,14,18,70};
constexpr int presetDisplay=firstFunctionKey+std::size(functionTargets);
constexpr int presetPrev=presetDisplay+1, presetNext=presetDisplay+2;
constexpr int selectedName=presetNext+1, syncIndex=selectedName+1, tailsIndex=syncIndex+1;
constexpr int stepBank=tailsIndex+1, firstBankButton=stepBank+1, firstStepLink=firstBankButton+2;
constexpr int stepLinkCount=8, stepTempoDial=firstStepLink+stepLinkCount, parameterCount=stepTempoDial+1;
constexpr int factoryPresetCount=std::size(factoryPresets);
constexpr const char* randomNames[]{"Steps","Seq","Matrix","NAND A","NAND B","All","555","4093","EFX"};
struct Instance {
    AEffect effect{};
    Engine engine;
    audioMasterCallback host=nullptr;
    std::atomic<int> target{0};
    std::atomic<bool> randomDown{false};
    std::atomic<uint32_t> randomSeed{0x9e3779b9};
    std::array<Parameter, parameterCount> parameters{};
    std::array<MidiNote, 256> events{};
    std::array<float, savedParameterCount+3> saved{};
    std::atomic<int> presetIndex{0};
    std::atomic<bool> hostSync{false}, tailsEnabled{false};
    std::atomic<int> stepEditBank{0};
    std::atomic<int> tempoEditTarget{21};
    std::array<int,2> shownStep{-1,-1};
    std::atomic<int> editTarget{0};
    std::atomic<int> selectedFunction{0};
    int count=0;
    double rate=44100;
    bool ready=false;

    Instance() {
        int index=0;
        auto add=[&](const char* name,std::atomic<int>& target,int low,int high,int bit=-1) {
            parameters[index++]={name,&target,low,high,bit};
        };
        add("Volume",engine.master,0,100);
        add("Seq",engine.transport,0,2);
        constexpr const char* names[]{"Rate 1","Rate 2","Rate 3","Link","Level",
            "Rate 1","Rate 2","Rate 3","Link","Level","Rate","Width","Level","Freq","Level"};
        constexpr const char* panNames[]{"NND1 Pan","NND2 Pan","555 Pan","4093 Pan"};
        for(int module=0;module<4;++module){
            for(int k=parameterStart[module];k<parameterStart[module+1];++k)
                add(names[k],engine.knobs[voiceIndex[module]][k-parameterStart[module]],0,100);
            add(panNames[module],engine.pan[module],-100,100);
        }
        constexpr const char* stepNames[]{"Step 1","Step 2","Step 3","Step 4","Step 5","Step 6"};
        for(int q=0;q<2;++q){
            add("Tempo",engine.bpm[q],30,300);
            add("Mode",engine.mode[q],0,2);
            for(int k=0;k<6;++k) {
                add(stepNames[k],engine.cv[q][k],24,96);
                add(stepNames[k],engine.mask[q],0,1,k);
            }
        }
        constexpr const char* dest[]{"555 Rate","555 PW","NAND A","NAND B","4093 Hz"};
        for(int i=0;i<20;++i) add(dest[i%5],engine.routes,0,1,i);
        ++index; // Run retains its original parameter ID.
        constexpr const char* fxNames[]{"Time","Pitch","Size","Diffuse","Filter","Feedbk","Reverb","EFX Mix"};
        for(int i=0;i<8;++i) add(fxNames[i],engine.efxValues[i],0,100);
        add("Target",target,0,8);
    }

    void randomize() {
        const int selection=target.load();
        const bool all=selection==5;
        uint32_t state=randomSeed.fetch_add(0x9e3779b9);
        auto choose=[&](int lo,int hi){
            state^=state<<13; state^=state>>17; state^=state<<5;
            return lo+int(state%unsigned(hi-lo+1));
        };
        for(int q=0;q<2;++q) {
            if(all || selection==0) for(int i=0;i<6;++i) engine.cv[q][i]=choose(36,72);
            if(all || selection==1) {
                engine.mask[q]=choose(0,63);
                engine.mode[q]=choose(0,2);
                engine.bpm[q]=choose(55,170);
            }
            if(all || selection==q+3) for(int i=0;i<4;++i) engine.knobs[q+1][i]=choose(0,100);
        }
        if(all || selection==6) for(int i=0;i<2;++i) engine.knobs[0][i]=choose(15,75);
        if(all || selection==7) engine.knobs[4][0]=choose(15,75);
        if(selection==8) for(int i=0;i<7;++i) engine.efxValues[i]=choose(10,70);
        if(all) for(auto& pan:engine.pan) pan=choose(-70,70);
        if(all || selection==2) engine.routes=choose(0,(1<<20)-1);
    }
};

int stepLinkTarget(int bank, int slot) {
    const int start=21+14*bank;
    if(slot<6) return start+2+2*slot;
    return start+(slot==6?1:0);
}

bool isStepPitch(int index) {
    return (index>=23 && index<=33 && index%2==1) || (index>=37 && index<=47 && index%2==1);
}

float parameterValue(const Parameter& param) {
    return float(param.read()-param.low)/(param.high-param.low);
}

void refreshStepLinks(AEffect* effect, Instance& p, int target=-1) {
    const int tempo=p.tempoEditTarget.load();
    if(target<0 || target==tempo)
        p.host(effect,audioMasterAutomate,stepTempoDial,0,nullptr,parameterValue(p.parameters[tempo]));
    const int bank=p.stepEditBank.load();
    for(int slot=0;slot<stepLinkCount;++slot) {
        const int real=stepLinkTarget(bank,slot);
        if(target<0 || target==real)
            p.host(effect,audioMasterAutomate,firstStepLink+slot,0,nullptr,parameterValue(p.parameters[real]));
    }
}

const char* selectedParameterName(const Instance& p) {
    const int index=p.editTarget.load();
    if(isStepPitch(index)) {
        constexpr const char* steps[][6]{
            {"A STEP 1","A STEP 2","A STEP 3","A STEP 4","A STEP 5","A STEP 6"},
            {"B STEP 1","B STEP 2","B STEP 3","B STEP 4","B STEP 5","B STEP 6"}
        };
        const int bank=index>=37;
        return steps[bank][(index-(bank?37:23))/2];
    }
    switch(index) {
        case 0: return "VOLUME";
        case 21: return "TEMPO A";
        case 22: return "MODE A";
        case 35: return "TEMPO B";
        case 36: return "MODE B";
        case 2: return "A RATE 1";
        case 3: return "A RATE 2";
        case 4: return "A RATE 3";
        case 5: return "A LINK";
        case 6: return "A LVL";
        case 8: return "B RATE 1";
        case 9: return "B RATE 2";
        case 10: return "B RATE 3";
        case 11: return "B LINK";
        case 12: return "B LVL";
        case 14: return "555 RATE";
        case 15: return "555 GATE";
        case 16: return "555 LVL";
        case 18: return "4093 HZ";
        case 19: return "4093 LVL";
        default: return p.parameters[index].name;
    }
}

void refreshSelectedParameter(AEffect* effect, Instance& p) {
    const int index=p.editTarget.load();
    const auto& param=p.parameters[index];
    p.host(effect,audioMasterAutomate,selectedName,0,nullptr,float(index)/77.0f);
    p.host(effect,audioMasterAutomate,valueDial,0,nullptr,parameterValue(param));
    p.host(effect,audioMasterUpdateDisplay,0,0,nullptr,0);
}

void loadFactoryPreset(AEffect* effect, Instance& p, int index) {
    if(index<0 || index>=factoryPresetCount) return;
    const auto& preset=factoryPresets[index];
    for(int i=0;i<int(std::size(preset.values));++i) {
        if(i==runIndex) continue;
        const auto& parameter=p.parameters[i];
        const int value=std::clamp(preset.values[i],parameter.low,parameter.high);
        if(value==parameter.read()) continue;
        parameter.write(value);
        p.host(effect,audioMasterAutomate,i,0,nullptr,float(value-parameter.low)/(parameter.high-parameter.low));
    }
    p.presetIndex=index;
    p.host(effect,audioMasterAutomate,presetDisplay,0,nullptr,float(index)/(factoryPresetCount-1));
    refreshStepLinks(effect,p);
    refreshSelectedParameter(effect,p);
}

void render(AEffect* effect,float**,float** out,int32_t frames) {
    auto& p=*static_cast<Instance*>(effect->object);
    if(p.ready) {
        bool syncChangedRun=false, restartClock=false;
        if(p.hostSync.load()) {
            const auto* time=reinterpret_cast<const VstTimeInfo*>(
                p.host(effect,audioMasterGetTime,0,kVstTempoValid, nullptr,0));
            const bool running=time && (time->flags & kVstTransportPlaying);
            syncChangedRun=p.engine.playing.exchange(running)!=running;
            restartClock=running && syncChangedRun;
            if(syncChangedRun) p.host(effect,audioMasterAutomate,runIndex,0,nullptr,running?1.0f:0.0f);
        }
        p.engine.render(out[0],out[1],frames,p.events.data(),p.count,p.tailsEnabled.load(),0,restartClock);
        bool changed=false;
        for(int q=0;q<2;++q) {
            const int step=p.engine.lamp[q].load();
            if(step==p.shownStep[q]) continue;
            p.shownStep[q]=step;
            p.host(effect,audioMasterAutomate,firstStepLight+q,0,nullptr,float(step+1)/6.0f);
            changed=true;
        }
        if(changed || syncChangedRun) p.host(effect,audioMasterUpdateDisplay,0,0,nullptr,0);
    }
    else for(int i=0;i<2;++i) if(out[i]) std::fill_n(out[i],frames,0.0f);
    p.count=0;
}

void set(AEffect* effect,int32_t index,float value) {
    if(!(value>=0 && value<=1) || index<0 || index>=parameterCount) return;
    auto& p=*static_cast<Instance*>(effect->object);
    if(index==stepBank) return;
    if(index==firstBankButton || index==firstBankButton+1) {
        if(value>=0.5f) {
            const int selected=index-firstBankButton;
            if(p.stepEditBank.exchange(selected)!=selected) {
                p.host(effect,audioMasterAutomate,stepBank,0,nullptr,float(selected));
                refreshStepLinks(effect,p);
                p.host(effect,audioMasterUpdateDisplay,0,0,nullptr,0);
            }
        }
        return;
    }
    if(index==stepTempoDial) {
        const int target=p.tempoEditTarget.load();
        const auto& param=p.parameters[target];
        if(value!=parameterValue(param)) {
            p.editTarget=target;
            set(effect,target,value);
        }
        return;
    }
    if(index>=firstStepLink) {
        const int slot=index-firstStepLink;
        const int target=stepLinkTarget(p.stepEditBank.load(),slot);
        auto& param=p.parameters[target];
        const int previous=param.read();
        int next=param.low+int(value*(param.high-param.low)+0.5f);
        if(slot==6 && next==previous && value!=parameterValue(param))
            next=std::clamp(previous+(value>parameterValue(param)?1:-1),param.low,param.high);
        if(next!=previous) {
            param.write(next);
            p.editTarget=target;
            p.host(effect,audioMasterAutomate,target,0,nullptr,parameterValue(param));
            if(target==p.tempoEditTarget.load())
                p.host(effect,audioMasterAutomate,stepTempoDial,0,nullptr,parameterValue(param));
            refreshSelectedParameter(effect,p);
        }
        return;
    }
    if(index==syncIndex) {
        const bool enabled=value>=0.5f;
        if(p.hostSync.exchange(enabled)!=enabled && p.engine.playing.exchange(false)) {
            p.host(effect,audioMasterAutomate,runIndex,0,nullptr,0);
            p.host(effect,audioMasterUpdateDisplay,0,0,nullptr,0);
        }
        return;
    }
    if(index==tailsIndex) { p.tailsEnabled=value>=0.5f; return; }
    if(index>=presetDisplay) {
        if((index==presetPrev || index==presetNext) && value>=0.5f) {
            const int step=index==presetPrev?-1:1;
            loadFactoryPreset(effect,p,(p.presetIndex.load()+step+factoryPresetCount)%factoryPresetCount);
        }
        return;
    }
    if(index==functionGroup) return;
    if(index>=firstFunctionKey) {
        if(value>=0.5f) {
            const int group=index-firstFunctionKey;
            p.editTarget=functionTargets[group];
            p.selectedFunction=group+1;
            p.host(effect,audioMasterAutomate,functionGroup,0,nullptr,float(group+1)/5.0f);
            refreshSelectedParameter(effect,p);
        }
        return;
    }
    if(index>=firstModeKey) {
        if(value>=0.5f) {
            auto& mode=p.engine.mode[index-firstModeKey];
            mode=(mode.load()+1)%3;
            refreshStepLinks(effect,p,22+14*(index-firstModeKey));
            p.host(effect,audioMasterUpdateDisplay,0,0,nullptr,0);
        }
        return;
    }
    if(index>=firstEditKey) {
        if(value>=0.5f) {
            const int target=editTargets[index-firstEditKey];
            if((target==21 || target==35) && p.tempoEditTarget.exchange(target)!=target)
                p.host(effect,audioMasterAutomate,stepTempoDial,0,nullptr,parameterValue(p.parameters[target]));
            if(p.editTarget.exchange(target)!=target)
                refreshSelectedParameter(effect,p);
        }
        return;
    }
    const bool fromValueDial=index==valueDial;
    if(fromValueDial) index=p.editTarget.load();
    if(index>=firstStepLight) return;
    if(index==runIndex){if(!p.hostSync.load()) p.engine.playing=value>=0.5f;return;}
    if(index==randomAction) {
        if(!p.randomDown.exchange(value>=0.5f) && value>=0.5f) {
            p.randomize();
            refreshStepLinks(effect,p);
            refreshSelectedParameter(effect,p);
        }
        return;
    }
    auto& param=p.parameters[index];
    const int next=param.low+int(value*(param.high-param.low)+0.5f);
    const bool changed=next!=param.read();
    param.write(next);
    if(changed) refreshStepLinks(effect,p,index);
    if(changed && !fromValueDial && index==p.editTarget.load()) refreshSelectedParameter(effect,p);
}
float get(AEffect* effect,int32_t index) {
    auto& p=*static_cast<Instance*>(effect->object);
    if(index==runIndex) return p.engine.playing.load();
    if(index<0 || index>=parameterCount) return 0;
    if(index==randomAction) return p.randomDown.load();
    if(index==syncIndex) return p.hostSync.load();
    if(index==tailsIndex) return p.tailsEnabled.load();
    if(index==stepBank) return float(p.stepEditBank.load());
    if(index==firstBankButton || index==firstBankButton+1) return 0;
    if(index==stepTempoDial) return parameterValue(p.parameters[p.tempoEditTarget.load()]);
    if(index>=firstStepLink) return parameterValue(p.parameters[stepLinkTarget(p.stepEditBank.load(),index-firstStepLink)]);
    if(index==selectedName) return float(p.editTarget.load())/77.0f;
    if(index>=presetDisplay) return index==presetDisplay?float(p.presetIndex.load())/(factoryPresetCount-1):0;
    if(index==functionGroup) return float(p.selectedFunction.load())/5.0f;
    if(index>=firstModeKey) return 0;
    if(index>=firstEditKey) return p.editTarget.load()==editTargets[index-firstEditKey];
    if(index==valueDial) index=p.editTarget.load();
    if(index>=firstStepLight) return float(p.engine.lamp[index-firstStepLight].load()+1)/6.0f;
    const auto& param=p.parameters[index];
    return float(param.read()-param.low)/(param.high-param.low);
}
VstIntPtr dispatch(AEffect* effect,int32_t op,int32_t index,VstIntPtr value,void* ptr,float opt) {
    auto& p=*static_cast<Instance*>(effect->object);
    switch(op){
        case effClose: delete &p; return 1;
        case effSetSampleRate: if(opt>0) p.rate=opt; return 1;
        case effMainsChanged:
            p.count=0;
            p.ready=false;
            if(value){try {p.engine.prepare(p.rate); p.ready=true;} catch(...) {}}
            return 1;
        case effGetChunk:
            if(!ptr) return 0;
            for(int i=0;i<savedParameterCount;++i) p.saved[i]=get(effect,i);
            p.saved[randomAction]=0;
            p.saved[runIndex]=0;
            p.saved[savedParameterCount]=float(p.presetIndex.load());
            p.saved[savedParameterCount+1]=p.hostSync.load();
            p.saved[savedParameterCount+2]=p.tailsEnabled.load();
            *static_cast<void**>(ptr)=p.saved.data();
            return sizeof(p.saved);
        case effSetChunk:
            if(!ptr || (value!=sizeof(p.saved) && value!=(savedParameterCount+1)*sizeof(float)
                && value!=savedParameterCount*sizeof(float) && value!=70*sizeof(float))) return 0;
            std::memcpy(p.saved.data(),ptr,size_t(value));
            for(int i=0;i<std::min(savedParameterCount,int(value/sizeof(float)));++i)
                if(i!=runIndex && i!=randomAction) set(effect,i,p.saved[i]);
            p.presetIndex=0;
            if(value>savedParameterCount*sizeof(float)) {
                const float index=p.saved[savedParameterCount];
                if(index>=0 && index<factoryPresetCount) p.presetIndex=int(index);
            }
            set(effect,syncIndex,value==sizeof(p.saved)?p.saved[savedParameterCount+1]:0.0f);
            set(effect,tailsIndex,value==sizeof(p.saved)?p.saved[savedParameterCount+2]:0.0f);
            return 1;
        case effProcessEvents: {
            if(!ptr) return 0;
            auto* list=static_cast<const VstEvents*>(ptr);
            auto* items=reinterpret_cast<VstEvent* const*>(reinterpret_cast<const char*>(list)+offsetof(VstEvents,events));
            for(int i=0;i<list->numEvents && p.count<int(p.events.size());++i){
                if(!items[i] || items[i]->type!=kVstMidiType) continue;
                auto& m=*reinterpret_cast<const VstMidiEvent*>(items[i]);
                auto* bytes=reinterpret_cast<const unsigned char*>(m.midiData);
                MidiNote note{m.deltaFrames,bytes[0],bytes[1]&127,bytes[2]&127};
                int pos=p.count++;
                while(pos>0 && p.events[pos-1].frame>note.frame){p.events[pos]=p.events[pos-1];--pos;}
                p.events[pos]=note;
            }
            return 1;
        }
        case effGetEffectName: std::strcpy(static_cast<char*>(ptr),"8Bit Schmitter Studio"); return 1;
        case effGetProductString: std::strcpy(static_cast<char*>(ptr),"8Bit Schmitter Studio"); return 1;
        case effGetVendorString: std::strcpy(static_cast<char*>(ptr),"TINYTHINGZ"); return 1;
        case effSetProgram: if(value>=0 && value<factoryPresetCount) loadFactoryPreset(effect,p,int(value)); return 1;
        case effGetProgram: return p.presetIndex.load();
        case effGetProgramNameIndexed:
            if(!ptr || index<0 || index>=factoryPresetCount) return 0;
            std::snprintf(static_cast<char*>(ptr),24,"%s",factoryPresets[index].name);
            return 1;
        case effGetProgramName:
            if(!ptr) return 0;
            std::snprintf(static_cast<char*>(ptr),24,"%s",factoryPresets[p.presetIndex.load()].name);
            return 1;
        case effGetParamName:
            if(index<0 || index>=parameterCount || !ptr) return 0;
            if(index==stepTempoDial) {
                std::strcpy(static_cast<char*>(ptr),p.tempoEditTarget.load()==21?"Tempo A":"Tempo B");
                return 1;
            }
            if(index>=firstStepLink) {
                const int slot=index-firstStepLink;
                const char bank=p.stepEditBank.load()?'B':'A';
                if(slot<6) std::snprintf(static_cast<char*>(ptr),9,"%c Step %d",bank,slot+1);
                else std::snprintf(static_cast<char*>(ptr),9,"%s %c",slot==6?"Mode":"Tempo",bank);
                return 1;
            }
            if(index>=stepBank) { std::strcpy(static_cast<char*>(ptr),"Bank"); return 1; }
            if(index==syncIndex || index==tailsIndex) {
                std::strcpy(static_cast<char*>(ptr),index==syncIndex?"Sync":"Tail");
                return 1;
            }
            if(index==selectedName) { std::strcpy(static_cast<char*>(ptr),"Control"); return 1; }
            if(index>=presetDisplay) { std::strcpy(static_cast<char*>(ptr),"Preset"); return 1; }
            if(index>=functionGroup) { std::strcpy(static_cast<char*>(ptr),"Group"); return 1; }
            if(index>=firstModeKey) { std::strcpy(static_cast<char*>(ptr),"Mode"); return 1; }
            if(index>=firstEditKey) index=editTargets[index-firstEditKey];
            if(index==valueDial) index=p.editTarget.load();
            if(index>=firstStepLight) {
                std::strcpy(static_cast<char*>(ptr),index==firstStepLight?"Light A":"Light B");
                return 1;
            }
            std::snprintf(static_cast<char*>(ptr),9,"%s",index==runIndex?"Run":index==randomAction?"Roll":p.parameters[index].name);
            return 1;
        case effGetParamDisplay: {
            if(index<0 || index>=parameterCount || !ptr) return 0;
            const bool stepLink=index>=firstStepLink && index<stepTempoDial;
            const bool sharedDial=index==valueDial;
            if(index==stepTempoDial) index=p.tempoEditTarget.load();
            else if(stepLink) index=stepLinkTarget(p.stepEditBank.load(),index-firstStepLink);
            else if(index>=stepBank) {
                std::strcpy(static_cast<char*>(ptr),p.stepEditBank.load()?"B":"A");
                return 1;
            }
            if(index==syncIndex || index==tailsIndex) {
                std::strcpy(static_cast<char*>(ptr),get(effect,index)>0?"On":"Off");
                return 1;
            }
            if(index==selectedName) {
                std::snprintf(static_cast<char*>(ptr),24,"%s",selectedParameterName(p));
                return 1;
            }
            if(index>=presetDisplay) {
                if(index==presetDisplay) std::snprintf(static_cast<char*>(ptr),24,"%s",factoryPresets[p.presetIndex.load()].name);
                else *static_cast<char*>(ptr)=0;
                return 1;
            }
            if(index>=functionGroup) {
                std::snprintf(static_cast<char*>(ptr),8,"%d",index==functionGroup?p.selectedFunction.load():0);
                return 1;
            }
            if(index>=firstModeKey) {
                std::strcpy(static_cast<char*>(ptr),"");
                return 1;
            }
            if(index>=firstEditKey) {
                std::strcpy(static_cast<char*>(ptr),get(effect,index)>0?"On":"Off");
                return 1;
            }
            if(index==valueDial) index=p.editTarget.load();
            if(index>=firstStepLight) {
                std::snprintf(static_cast<char*>(ptr),8,"%d",p.engine.lamp[index-firstStepLight].load()+1);
                return 1;
            }
            int n=index==runIndex?p.engine.playing.load():index==randomAction?p.randomDown.load():p.parameters[index].read();
            if(index==randomTarget) { std::snprintf(static_cast<char*>(ptr),8,"%s",randomNames[n]); return 1; }
            if(isStepPitch(index)) {
                constexpr const char* notes[]{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
                std::snprintf(static_cast<char*>(ptr),8,"%s%d",notes[n%12],n/12-1);
            } else if((sharedDial || stepLink) && (index==22 || index==36)) {
                constexpr const char* modes[]{"FWD","REV","RND"};
                std::strcpy(static_cast<char*>(ptr),modes[n]);
            } else if(index==1 || index==22 || index==36) {
                const char* values[]{"Fwd","Back","Random"};
                const char* seqs[]{"A","A+B","B"};
                std::snprintf(static_cast<char*>(ptr),8,"%s",(index==1?seqs:values)[n]);
            } else if(index==runIndex || index==randomAction || p.parameters[index].bit>=0)
                std::snprintf(static_cast<char*>(ptr),8,"%s",n?"On":"Off");
            else std::snprintf(static_cast<char*>(ptr),8,"%d",n);
            return 1;
        }
        case effGetParamLabel: if(ptr) *static_cast<char*>(ptr)=0; return 1;
        case effCanBeAutomated: return (index>=0 && index<randomAction) || index==syncIndex || index==tailsIndex
            || (index>=firstStepLink && index<parameterCount);
        case effGetTailSize: return p.tailsEnabled.load()?VstIntPtr(effectTailSeconds*p.rate):1;
        case effGetPlugCategory: return kPlugCategSynth;
        case effGetVstVersion: return 2400;
        case effGetVendorVersion: return 1000;
        case effCanDo: return ptr && (!std::strcmp(static_cast<const char*>(ptr),"receiveVstEvents")
            || !std::strcmp(static_cast<const char*>(ptr),"receiveVstMidiEvent")
            || !std::strcmp(static_cast<const char*>(ptr),"receiveVstTimeInfo")) ? 1 : 0;
        default:return 0;
    }
}
}
extern "C" __attribute__((visibility("default"))) AEffect* VSTPluginMain(audioMasterCallback host) {
    if(!host || !host(nullptr,audioMasterVersion,0,0,nullptr,0))return nullptr;
    auto* p=new(std::nothrow) Instance;
    if(!p)return nullptr;
    p->host=host;
    auto& e=p->effect;
    e.magic=kEffectMagic;e.dispatcher=dispatch;e.setParameter=set;e.getParameter=get;
    e.numPrograms=factoryPresetCount;e.numParams=parameterCount;e.numOutputs=2;e.flags=effFlagsCanReplacing|effFlagsIsSynth|effFlagsProgramChunks;
    e.object=p;e.uniqueID=0x53685374;e.version=1000;e.processReplacing=render;
    return &e;
}

