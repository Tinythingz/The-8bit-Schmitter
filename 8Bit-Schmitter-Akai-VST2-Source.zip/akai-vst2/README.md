# The 8Bit Schmitter for Akai MPC OS

This folder contains the standalone Akai VST2 instrument source. See the repository release for the packaged plugin and skin.

## Build the shared library

From this folder, using Zig 0.15.2:

```sh
zig c++ -target arm-linux-gnueabihf.2.31 -mcpu=cortex_a17 -std=c++17 -O2 -shared -fPIC -fvisibility=hidden -Ivendor plugin.cpp vendor/stmlib/dsp/units.cc vendor/clouds/dsp/mu_law.cc -o schmitter-arm32.so
zig c++ -target aarch64-linux-gnu.2.31 -mcpu=generic -std=c++17 -O2 -shared -fPIC -fvisibility=hidden -Ivendor plugin.cpp vendor/stmlib/dsp/units.cc vendor/clouds/dsp/mu_law.cc -o schmitter-arm64.so
```

Start with the Akai VST2 release folder and replace the corresponding library in its VST subfolder. The skin and plugin metadata are included in the release.

The Akai VST2 source is MIT-licensed. Third-party DSP notices are in the repository root.
