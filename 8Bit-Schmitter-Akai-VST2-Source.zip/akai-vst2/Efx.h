#pragma once
// Portable host wrapper around the Mutable Instruments Clouds delay, diffuser,
// pitch shifter and reverb. The original MIT notices remain in the source.
#define TEST
#if defined(_MSC_VER) && !defined(__clang__)
#define __attribute__(x)
#endif
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "clouds/dsp/looping_sample_player.h"
#include "clouds/dsp/fx/diffuser.h"
#include "clouds/dsp/fx/pitch_shifter.h"
#include "clouds/dsp/fx/reverb.h"
#undef TEST
#if defined(_MSC_VER) && !defined(__clang__)
#undef __attribute__
#endif

class EfxEffect
{
public:
    void prepare(double sampleRate)
    {
        rate=sampleRate;
        tape.resize(static_cast<size_t>(sampleRate*1.2)+16);
        reset();
    }

    void reset()
    {
        if(tape.empty())return;
        delay.Init(tape.data(),static_cast<int32_t>(tape.size()),tail.data());
        looper.Init(1);
        diffuser.Init(diffusionMemory.data());
        shifter.Init(pitchMemory.data());
        reverb.Init(reverbMemory.data());
        params={};
        low=high=feedbackSample=0;
        wet=0;
    }

    void set(const int* v)
    {
        params.position=static_cast<float>((10.0*std::pow(120.0,v[0]/100.0))/1200.0);
        const float pitch=static_cast<float>((v[1]-50)*.24);
        shifter.set_ratio(std::exp2(pitch/12));
        shifted=std::abs(pitch)>.01f;
        shifter.set_size(v[2]/100.0f);
        diffuser.set_amount(v[3]/100.0f);
        diffused=v[3]>0;
        const double filter=v[4]/100.0;
        const double lowCut=filter<.5?20000*std::pow(0.007,1-2*filter):20000;
        const double highCut=filter>.5?20*std::pow(250.0,2*filter-1):20;
        lowCoeff=float(-std::expm1(-6.283185307179586*std::min(rate*.44,lowCut)/rate));
        highCoeff=float(-std::expm1(-6.283185307179586*highCut/rate));
        feedback=.91f*v[5]/100;
        const float rev=v[6]*.0095f;
        reverb.set_amount(rev*.54f);
        reverb.set_diffusion(.7f);
        reverb.set_time(.35f+.63f*rev);
        reverb.set_input_gain(.2f);
        reverb.set_lp(.6f+.37f*feedback);
        reverbOn=v[6]>0;
        targetWet=v[7]/100.0f;
    }

    float dryGain() const {return 1-.25f*wet;}

    clouds::FloatFrame process(float dry)
    {
        if(tape.empty())return {dry,dry};
        delay.Write(std::tanh(dry+feedback*feedbackSample));
        clouds::FloatFrame frame{};
        looper.Play(&delay,params,&frame.l,1);
        if(diffused)diffuser.Process(&frame,1);
        // Keep the shifter's delay lines primed even at zero transposition.
        auto pitched=frame;
        shifter.Process(&pitched,1);
        if(shifted)frame=pitched;
        const float mono=(frame.l+frame.r)*.5f;
        low+=(mono-low)*lowCoeff;
        high+=(low-high)*highCoeff;
        const float filtered=low-high;
        frame.l+=filtered-mono;frame.r+=filtered-mono;
        feedbackSample=filtered;
        if(reverbOn)reverb.Process(&frame,1);
        wet+=(targetWet-wet)*.002f;
        const float direct=dry*dryGain();
        return {direct+frame.l*wet,direct+frame.r*wet};
    }
private:
    double rate=48000;
    std::vector<int16_t> tape;
    std::array<int16_t,256> tail{};
    std::array<float,2048> diffusionMemory{};
    std::array<uint16_t,4096> pitchMemory{};
    std::array<uint16_t,16384> reverbMemory{};
    clouds::AudioBuffer<clouds::RESOLUTION_16_BIT> delay;
    clouds::LoopingSamplePlayer looper;
    clouds::Diffuser diffuser;
    clouds::PitchShifter shifter;
    clouds::Reverb reverb;
    clouds::Parameters params{};
    float feedback=0,feedbackSample=0,low=0,high=0,lowCoeff=0,highCoeff=0,wet=0,targetWet=0;
    bool shifted=false,diffused=false,reverbOn=false;
};

