#include "mpc_vst2_abi.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <new>
#include <vector>

#include "Efx.h"

namespace {
using std::min;
template<class T> T jlimit(T low,T high,T value) { return std::clamp(value,low,high); }
template<class T> T jmin(T a,T b) { return std::min(a,b); }

struct MidiNote { int frame, status, key, value; };
constexpr int levels[] { 2, 4, 4, 2, 1 };
constexpr double ln2 = 0.6931471805599453;
double noteHz(int note){return 440.0*std::exp2((note-69)/12.0);}
double hz(int x, double lo, double hi) { return lo * std::pow(hi / lo, x / 100.0); }

constexpr int parameterStart[]{0,5,10,13,15};
constexpr int voiceIndex[]{1,2,0,4};
constexpr int effectTailSeconds=20;

class Engine {
public:
    Engine()
    {
        const int defaults[5][5] {{28,51,100,0,0},{34,77,3,100,100},{37,44,49,100,100},{53,0,0,0,0},{48,100,0,0,0}};
        const int steps[2][6] {{48,51,55,58,55,51},{36,43,46,43,39,46}};
        for (int v=0; v<5; ++v) for(int k=0;k<5;++k) knobs[v][k]=defaults[v][k];
        for (int q=0; q<2; ++q) for(int k=0;k<6;++k) cv[q][k]=steps[q][k];
        bpm[0]=120; bpm[1]=87;
        mask[0]=0; mask[1]=0;
        lamp[0]=-1; lamp[1]=-1;

    }

    std::atomic<int> knobs[5][5]{}, cv[2][8]{}, bpm[2]{}, mask[2]{}, mode[2]{}, lamp[2]{};
    std::atomic<int> pan[4]{};
    std::atomic<int> routes{0}, master{25}, transport{1};
    std::atomic<int> efxValues[8]{58,50,45,20,50,35,25,0};
    std::atomic<bool> playing{false};
    void prepare(double rate)
    {
        sampleRate=rate;
        dt=1/(8*rate);
        discharge=-std::expm1(-dt/.0001);
        dc=std::exp(-2*3.141592653589793*12/rate);
        glide=-std::expm1(-1/(rate*.012));
        efx.prepare(rate);
        heldCount=0;reset();
    }
    void render(float* out, float* right, int frames, const MidiNote* midi, int count,
                bool tails=false, double hostTempo=0, bool restartClock=false)
    {
        if (!out || frames <= 0) return;
        std::fill_n(out, frames, 0.0f);
        if (right) std::fill_n(right, frames, 0.0f);
        const bool run=playing.load();
        const double gain=master.load()/100.0;
        if(!tails) tailSamples=0;
        if(!run && !wasPlaying && heldCount==0 && count==0 && tailSamples==0) return;
        int fx[8];
        for(int i=0;i<8;++i) fx[i]=efxValues[i].load();
        efx.set(fx);
        if(!run && !wasPlaying && heldCount==0 && count==0) {
            const int remaining=std::min(frames,tailSamples);
            for(int i=0;i<remaining;++i) {
                const auto wet=efx.process(0);
                const double fade=std::min(1.0,tailSamples/(sampleRate*.1));
                volume+=(gain-volume)*glide;
                out[i]=float((right?wet.l:(wet.l+wet.r)*.5)*volume*fade);
                if(right) right[i]=float(wet.r*volume*fade);
                --tailSamples;
            }
            return;
        }
        const int patch=routes.load();
        int v[5][5], stepValues[2][6], stepMask[2];
        double tempo[2];
        const int runSelection=transport.load();
        const bool clocking[]{run&&runSelection!=2,run&&runSelection!=0};
        const int panTarget[]{pan[2].load(),pan[0].load(),pan[1].load(),0,pan[3].load()};
        for(int voice=0;voice<5;++voice) for(int k=0;k<5;++k) v[voice][k]=knobs[voice][k].load();
        for(int q=0;q<2;++q)
        {
            for(int k=0;k<6;++k) stepValues[q][k]=cv[q][k].load();
            stepMask[q]=mask[q].load();
            tempo[q]=hostTempo>0 ? hostTempo : double(bpm[q].load());
            const int newMode=mode[q].load();
            if(restartClock || seq[q].mode!=newMode)
            {
                seq[q]={}; seq[q].mode=newMode;
                seq[q].step=newMode==1?5:0;
            }
            lamp[q]=clocking[q] ? seq[q].step : -1;
        }
        const double clock=hz(v[0][0],20,6870);
        const double rates[]{hz(v[1][0],.25,25),hz(v[1][1],1,160),hz(v[1][2],45,1800),
            hz(v[2][0],.25,25),hz(v[2][1],1,160),hz(v[2][2],45,1800),
            hz(v[3][0],.5,2400),hz(v[4][0],.5,2400)};
        double coeff[8];
        for(int i=0;i<8;++i) coeff[i]=-std::expm1(-2*ln2*rates[i]*dt);
        int event=0;
        for(int i=0;i<frames;++i)
        {
            while(event<count && midi[event].frame<=i) handleMidi(midi[event++]);
            const bool sounding=run || heldCount>0;
            if(sounding && !wasPlaying)
            {
                reset(!tails || tailSamples==0);
                efx.set(fx);
                for(int q=0;q<2;++q)
                {
                    seq[q].mode=mode[q].load();
                    seq[q].step=seq[q].mode==1?5:0;
                    lamp[q]=clocking[q]?seq[q].step:-1;
                }
                wasPlaying=true;
            }
            const double keyboard=heldCount>0?noteHz(held[heldCount-1]%128):0.0;
            for(int q=0;q<2;++q)
            {
                if(!clocking[q])continue;
                auto& s=seq[q];
                s.phase+=tempo[q]/(30*sampleRate);
                if(s.phase>=1)
                {
                    s.phase-=1;
                    s.step=s.mode==2?(s.step+1+random.nextInt(5))%6
                                    :(s.step+(s.mode==1?5:1))%6;
                    lamp[q]=run ? s.step : -1;
                }
            }
            double sum[5]{};
            for(int sub=0;sub<8;++sub)
            {
                double pitch=0,width=0,schmittPitch=0,clockNotes=0,schmittNotes=0;
                int clockCount=0,schmittCount=0;
                bool enableA=true, enableB=true;
                for(int row=0;row<4;++row)
                {
                    const int bits=(patch>>(row*5))&31;
                    if(bits==0 || (row<2 && (!clocking[row] || !(stepMask[row]&(1<<seq[row].step))))) continue;
                    const int note=row<2?stepValues[row][seq[row].step]:0;
                    const double value=row<2?jlimit(0.0,1.0,(note-24)/72.0):double(gates[row==2?2:5].high);
                    const auto bi=2*value-1;
                    if(bits&1){if(row<2){clockNotes+=note;++clockCount;}else pitch+=.35*bi;}
                    if(bits&2) width+=.17*bi;
                    if(bits&4) enableA=enableA && value>=.5;
                    if(bits&8) enableB=enableB && value>=.5;
                    if(bits&16){if(row<2){schmittNotes+=note;++schmittCount;}else schmittPitch+=.35*bi;}
                }
                const double clockBase=keyboard>0?keyboard:clockCount?440.0*std::exp2((clockNotes/clockCount-69)/12):clock;
                const double charge=-std::expm1(-dt/(1/(jmin(10000.0,clockBase*std::exp2(pitch))*ln2)-.0001));
                if(!apcClock && apcCap<=1.0/3) { apcCap=1.0/3; apcClock=true; }
                else if(apcCap>=2.0/3) apcClock=false;
                apcCap+=apcClock ? (1-apcCap)*charge : -apcCap*discharge;
                if(!apcClock) apcOut=true;
                else if(pulseCap>=2.0/3) apcOut=false;
                const double w=jlimit(0.0,1.0,v[0][1]/100.0+width);
                pulseCap=apcOut ? pulseCap+(1-pulseCap)*(-std::expm1(-dt/((1000+500000*w)*1e-8))) : 0;
                sum[0]+=apcOut;
                for(int bank=0;bank<2;++bank)
                {
                    const int g=3*bank, coupling=v[bank+1][3];
                    const bool first=tick(g,true,coeff);
                    const bool second=tick(g+1,coupling<34 || first,coeff);
                    sum[bank+1]+=tick(g+2,(bank==0?enableA:enableB) && (coupling<67 || second),coeff);
                }
                const double schmittBase=keyboard>0?keyboard:schmittCount?440.0*std::exp2((schmittNotes/schmittCount-69)/12):rates[7];
                coeff[7]=-std::expm1(-2*ln2*schmittBase*std::exp2(schmittPitch)*dt);
                sum[4]+=tick(7,true,coeff);
            }
            double left=0,rightMix=0;
            for(int k=0;k<5;++k)
            {
                if(k==3)continue;
                const double target=(run || (heldCount>0 && (k==0 || k==4))) ? v[k][levels[k]]/100.0 : 0.0;
                mix[k]+=(target-mix[k])*glide;
                panMix[k]+=(panTarget[k]/100.0-panMix[k])*glide;
                const double voice=mix[k]*sum[k]/8;
                left+=voice*(1-std::max(0.0,panMix[k]));
                rightMix+=voice*(1+std::min(0.0,panMix[k]));
            }
            const double mid=(left+rightMix)*.5, side=(left-rightMix)*.5;
            filtered=mid-previous+dc*filtered; previous=mid;
            filteredSide=side-previousSide+dc*filteredSide; previousSide=side;
            if(tails && sounding && fx[7]>0) tailSamples=int(effectTailSeconds*sampleRate);
            tailGate+=((sounding?1.0:0.0)-tailGate)*glide;
            volume+=(((tails||sounding)?gain:0.0)-volume)*glide;
            const double envelope=tails?tailGate:1.0;
            const auto stereo=efx.process(float(filtered*.19*envelope));
            const float sideOut=float(filteredSide*.19*envelope)*efx.dryGain();
            out[i]=float((right?stereo.l+sideOut:(stereo.l+stereo.r)*.5f)*volume);
            if(right) right[i]=float((stereo.r-sideOut)*volume);
        }
        wasPlaying=run || heldCount>0 || (tails?tailGate:volume)>0.0001;
    }
    struct Gate { double cap=1.0/3; bool sensed=false, high=true; };
    struct Seq { double phase=0; unsigned index=0; int step=0, mode=-1; };
    Gate gates[8]; Seq seq[2];
    std::array<int,16*128> held{};
    int heldCount=0;
    void handleMidi(const MidiNote& event)
    {
        const int channel=event.status&15;
        const int type=event.status&240;
        if(type==0xb0 && (event.key==120 || event.key==123))
            heldCount=int(std::remove_if(held.begin(),held.begin()+heldCount,
                [channel](int key){return key/128==channel;})-held.begin());
        if(type!=0x80 && type!=0x90) return;
        const int key=channel*128+event.key;
        heldCount=int(std::remove(held.begin(),held.begin()+heldCount,key)-held.begin());
        if(type==0x90 && event.value) held[heldCount++]=key;
    }
    struct Random {
        uint32_t state=0x9e3779b9;
        int nextInt(int range) {
            state ^= state << 13; state ^= state >> 17; state ^= state << 5;
            return int(state % unsigned(range));
        }
    } random;
    EfxEffect efx;
    double sampleRate=48000,dt=0,dc=0,glide=0,discharge=0;
    double apcCap=1.0/3,pulseCap=0,previous=0,filtered=0,volume=0,mix[5]{};
    double previousSide=0,filteredSide=0,panMix[5]{};
    bool apcClock=true,apcOut=false,wasPlaying=false;
    double tailGate=0;
    int tailSamples=0;
    void reset(bool clearEffects=true)
    {
        for(auto& g:gates) g={};
        for(auto& s:seq) s={};
        for(auto& m:mix) m=0;
        panMix[0]=pan[2].load()/100.0;
        panMix[1]=pan[0].load()/100.0;
        panMix[2]=pan[1].load()/100.0;
        panMix[4]=pan[3].load()/100.0;
        previousSide=filteredSide=0;
        apcCap=1.0/3; pulseCap=previous=filtered=volume=0;
        apcClock=true; apcOut=wasPlaying=false;
        tailGate=0;
        if(clearEffects) {
            tailSamples=0;
            efx.reset();
        }
    }
    bool tick(int i,bool enabled,const double* coeff)
    {
        auto& g=gates[i];
        g.high=!(enabled && g.sensed);
        g.cap+=(double(g.high)-g.cap)*coeff[i];
        if(g.cap>=2.0/3) g.sensed=true;
        else if(g.cap<=1.0/3) g.sensed=false;
        return g.high;
    }
};


